﻿using System;

namespace HW_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(
                "It's easy to win forgiveness for being wrong;\nbeing right is what gets you into real trouble.\nBjarne Stroustrup");
        }
    }
}