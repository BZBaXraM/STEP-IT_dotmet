﻿using System;

namespace HW_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, num2, num3, num4, num5;
            int max = 0;
            int min = 0;

            Console.Write("Enter first number: ");
            num = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the fourth number: ");
            num4 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the final number: ");
            num5 = Convert.ToInt32(Console.ReadLine());

            max = num;
            if (max < num2) max = num2;
            if (max < num3) max = num3;
            if (max < num4) max = num4;
            if (max < num5) max = num5;

            min = num;
            if (min > num2) min = num2;
            if (min > num3) min = num3;
            if (min > num4) min = num4;
            if (min > num5) min = num5;

            Console.WriteLine();
            Console.WriteLine($"Sun of five numbers: {num + num2 + num3 + num4 + num5}");
            Console.WriteLine();
            Console.WriteLine($"Max of five numbers: {max}");
            Console.WriteLine();
            Console.WriteLine($"Min of five numbers: {min}");
            Console.WriteLine();
            Console.WriteLine($"Product of five numbers {num * num2 * num3 * num4 * num5}");
        }
    }
}