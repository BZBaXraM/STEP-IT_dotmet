﻿using System;

namespace HW_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int tmp = 0;
            Console.Write("Enter number: ");
            num = Convert.ToInt32(Console.ReadLine());

            while (num > 0)
            {
                tmp = tmp * 10 + num % 10;
                num /= 10;
            }

            Console.WriteLine($"Reversed number: {tmp}");
        }
    }
}