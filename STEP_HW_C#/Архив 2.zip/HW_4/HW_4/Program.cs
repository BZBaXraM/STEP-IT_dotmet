﻿using System;

namespace HW_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.Write("Enter number of range for generate fib numbers: ");
            num = Convert.ToInt32(Console.ReadLine());

            int[] fibonacci = new int[num];

            int fibOne = 0;
            int fibTwo = 1;

            int fibRange;

            fibonacci[0] = fibOne;
            fibonacci[1] = fibTwo;

            for (int i = 2; i < num; i++)
            {
                fibRange = fibOne + fibTwo;
                fibonacci[i] = fibRange;

                fibOne = fibTwo;
                fibTwo = fibRange;
            }

            foreach (int item in fibonacci)
            {
                Console.Write(item + " ");
            }

            Console.WriteLine();
        }
    }
}