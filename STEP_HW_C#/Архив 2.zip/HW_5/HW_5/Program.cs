﻿using System;

namespace HW_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number of A: ");
            int A = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter number of B: ");
            int B = Convert.ToInt32(Console.ReadLine());

            while (A < B)
            {
                for (; A <= B; A++)
                {
                    Console.Write(A + "\t");
                }
            }
        }
    }
}