﻿using System;

namespace HW_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int symbCount, lineType;
            char symbol;
            Console.Write("Enter the number of characters in the line: ");
            symbCount = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter some character: ");
            symbol = Char.Parse(Console.ReadLine());

            Console.Write("Select line type: ");
            Console.WriteLine("1. Vertical line, " +
                              " 2. Horizontal line");
            lineType = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < symbCount; i++)
            {
                if (lineType == 1)
                {
                    Console.WriteLine(symbol);
                }

                if (lineType == 2)
                {
                    Console.Write(symbol + " ");
                }
            }

            Console.WriteLine();
        }
    }
}