﻿namespace HW
{
    class Fraction
    {
        public double numerator;
        public int denominator;

        public Fraction()
        {
        }

        public Fraction(int numerator, int denominator)
        {
            this.numerator = numerator;
            this.denominator = denominator;
        }

        public static Fraction operator +(Fraction f1, int x)
        {
            return new Fraction {numerator = f1.numerator + x, denominator = f1.denominator};
        }

        public static Fraction operator +(Fraction f1, double x)
        {
            return new Fraction {numerator = f1.numerator + x, denominator = f1.denominator};
        }

        public static Fraction operator -(Fraction f1, int x)
        {
            return new Fraction {numerator = f1.numerator - x, denominator = f1.denominator};
        }

        public static Fraction operator *(Fraction f1, int x)
        {
            return new Fraction {numerator = f1.numerator * x, denominator = f1.denominator};
        }

        public static Fraction operator /(Fraction f1, int x)
        {
            return new Fraction {numerator = f1.numerator / x, denominator = f1.denominator};
        }

        public static Fraction operator +(int x, Fraction f1)
        {
            return new Fraction {numerator = f1.numerator + x, denominator = f1.denominator};
        }

        public static Fraction operator -(int x, Fraction f1)
        {
            return new Fraction {numerator = f1.numerator - x, denominator = f1.denominator};
        }

        public static Fraction operator *(int x, Fraction f1)
        {
            return new Fraction {numerator = f1.numerator * x, denominator = f1.denominator};
        }

        public static Fraction operator /(int x, Fraction f1)
        {
            return new Fraction {numerator = f1.numerator / x, denominator = f1.denominator};
        }

        public static bool operator <(Fraction f1, Fraction f2)
        {
            return f1.numerator < f2.denominator;
        }

        public static bool operator >(Fraction f1, Fraction f2)
        {
            return f1.numerator > f2.denominator;
        }

        public static bool operator true(Fraction f1)
        {
            if (f1.numerator < f1.denominator)
            {
                return true;
            }

            return false;
        }

        public static bool operator false(Fraction f1)
        {
            if (f1.denominator < f1.numerator)
            {
                return true;
            }

            return false;
        }

        public static bool operator ==(Fraction f1, Fraction f2) => f1.numerator == f2.denominator;

        public static bool operator !=(Fraction f1, Fraction f2) => f1.numerator != f2.denominator;

        public override string ToString() => $"{numerator} / {denominator}";


        class Program
        {
            static void Main(string[] args)
            {
                Fraction f = new Fraction(3, 6);
                int a = 10;
                Fraction f1 = f * a;
                Fraction f2 = a * f;
                double d = 55.5;
                Fraction f3 = f + d;
                Console.WriteLine(f1);
                Console.WriteLine(f2);
                Console.WriteLine(f3);
            }
        }
    }
}