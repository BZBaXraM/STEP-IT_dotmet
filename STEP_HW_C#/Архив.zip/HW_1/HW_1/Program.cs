﻿using System;

namespace HW_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[5];
            double[,] B = new double[3, 4];
            int sum = A[0];
            int min;
            int max;
            int product = 1;
            int even = 0;
            double dMin;
            double dMax;
            double dSum = B[0, 0];
            double dProduct = 1.1;
            int maxElem = A[4];

            int minElem;
            int generic;
            var r = new Random();

            Console.WriteLine("Enter the 5 elements for array A: ");
            for (int i = 0; i < 5; i++)
            {
                A[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < A.Length; i++)
            {
                Console.Write(A[i] + " ");
            }

            Console.WriteLine();
            min = A[0];
            for (int i = 0; i < 5; i++)
            {
                if (min > A[i])
                {
                    min = A[i];
                }
            }

            max = A[0];

            for (int i = 0; i < 5; i++)
            {
                if (max < A[i])
                {
                    max = A[i];
                }
            }


            foreach (var item in A)
            {
                sum += item;
            }

            for (int i = 0; i < 5; i++)
            {
                product *= A[i];
            }

            for (int i = 0; i < 5; i++)
            {
                if (A[i] % 2 == 0)
                {
                    even += A[i];
                }
            }

            Console.WriteLine();

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    B[i, j] = r.NextDouble() * 100 + 20;
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(B[i, j] + " ");
                }

                Console.WriteLine();
            }

            dMin = B[0, 0];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (dMin > B[i, j])
                    {
                        dMin = B[i, j];
                    }
                }
            }

            dMax = B[0, 0];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (dMax < B[i, j])
                    {
                        dMax = B[i, j];
                    }
                }
            }

            foreach (var val in B)
            {
                dSum += val;
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    dProduct *= B[i, j];
                }
            }

            for (int i = 0; i < A.Length - 2; i++)
            {
                for (int j = 0; j < A.Length - 2; j++)
                {
                    if (A[j] > A[j + 1])
                    {
                        generic = A[j + 1];
                        A[j + 1] = A[j];
                        A[j] = generic;
                    }
                }
            }

            generic = 0;
            for (int i = 4; i > 0; i--)
            {
                if (generic == 0)
                {
                    maxElem = A[i];
                }

                foreach (var item in B)
                {
                    if (maxElem == item)
                    {
                        generic = 1;
                    }
                    else if (generic != 1)
                    {
                        generic = 0;
                    }
                }
            }

            if (generic == 0)
            {
                Console.WriteLine("Generic max element not found for A and B!");
            }
            else
            {
                Console.WriteLine($"Generic max element for the A and B: {maxElem}");
            }

            minElem = A[0];
            generic = 0;
            for (int i = 0; i < 5; i++)
            {
                if (generic == 0)
                {
                    minElem = A[i];
                }

                foreach (var item in B)
                {
                    if (minElem == item)
                    {
                        generic = 1;
                    }
                    else if (generic != 1)
                    {
                        generic = 0;
                    }
                }
            }

            if (generic == 0)
            {
                Console.WriteLine("Generic min element not found for A and B!");
            }
            else
            {
                Console.WriteLine($"Generic min element for the A and B: {minElem}");
            }

            Console.WriteLine();

            Console.WriteLine($"Min element of array A: {min}");
            Console.WriteLine($"Max element of array A: {max}");
            Console.WriteLine($"Sum of array A: {sum}");
            Console.WriteLine($"Product of array A: {product}");
            Console.WriteLine($"Sum of even elements of array A: {even}");
            Console.WriteLine();
            Console.WriteLine($"Min value of array B: {dMin}");
            Console.WriteLine($"Max element of array B: {dMax}");
            Console.WriteLine($"Sum of array B: {dSum}");
            Console.WriteLine($"Product of array B: {dProduct}");
        }
    }
}