﻿using System;

namespace HW_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[5, 5];
            var random = new Random();
            int sum = 0;
            int min = 0;
            int max = 0;
            int minIndex = 0;
            int minIndexTwo = 0;
            int maxIndex = 0;
            int maxIndexTwo = 0;
            int temp = 0;

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    arr[i, j] = random.Next(-100, 100);
                }
            }

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(arr[i, j] + " \t");
                }

                Console.WriteLine();
            }

            min = arr[0, 0];
            max = arr[0, 0];
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (arr[i, j] < min)
                    {
                        min = arr[i, j];
                        minIndexTwo = j;
                        minIndex = i;
                    }

                    if (arr[i, j] > max)
                    {
                        max = arr[i, j];
                        maxIndex = j;
                        maxIndexTwo = i;
                    }
                }
            }

            if (maxIndex < minIndex)
            {
                for (int i = maxIndex; i <= minIndex; i++)
                {
                    if (temp == 0)
                    {
                        for (int j = maxIndexTwo + 1; j < 5; j++)
                        {
                            sum += arr[i, j];
                        }

                        temp++;
                    }
                    else
                    {
                        if (i != minIndex)
                        {
                            for (int j = 0; j < 5; j++)
                            {
                                sum += arr[i, j];
                            }
                        }
                        else
                        {
                            for (int j = 0; j < minIndexTwo; j++)
                            {
                                sum += arr[i, j];
                            }
                        }
                    }
                }
            }
            else if (maxIndex > minIndex)
            {
                for (int i = minIndex; i <= maxIndex; i++)
                {
                    if (temp == 0)
                    {
                        for (int j = maxIndexTwo + 2; j < 5; j++)
                        {
                            sum += arr[i, j];
                        }

                        temp++;
                    }
                    else
                    {
                        if (i != maxIndex)
                        {
                            for (int j = 0; j < 5; j++)
                            {
                                sum += arr[i, j];
                            }
                        }
                        else
                        {
                            for (int j = 0; j < maxIndexTwo; j++)
                            {
                                sum += arr[i, j];
                            }
                        }
                    }
                }
            }
            else if (minIndex == maxIndex)
            {
                if (maxIndexTwo < minIndexTwo)
                {
                    for (int i = maxIndexTwo + 1; i < minIndexTwo; i++)
                    {
                        sum += arr[maxIndexTwo, i];
                    }
                }
                else if (maxIndexTwo > minIndexTwo)
                {
                    for (int i = minIndexTwo + 1; i < maxIndexTwo; i++)
                    {
                        sum += arr[minIndex, i];
                    }
                }
            }


            Console.WriteLine($"Minimal elements of array: {min}");
            Console.WriteLine($"Maximal elements of array: {max}");
            Console.WriteLine($"Sum of the other elements in array: {sum}");
        }
    }
}