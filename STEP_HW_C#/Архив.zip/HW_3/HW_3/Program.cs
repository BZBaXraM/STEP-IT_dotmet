﻿using System;

namespace HW_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            Console.Write("Enter the word: ");
            string word = Console.ReadLine();
            char[] symbWord = new char[word.Length];

            for (int i = 0; i < word.Length; i++)
            {
                symbWord[i] = Convert.ToChar(Convert.ToInt32(word[i]) + 5);
            }

            Console.Write("Your word in caesar cipher: ");
            foreach (var item in symbWord)
            {
                Console.Write(item);
            }

            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine("Do you want to decipher the word? : " +
                              " 1 - Yes, 0 - No");
            choice = Convert.ToInt32(Console.ReadLine());
            if (choice == 1)
            {
                Console.WriteLine($"Your word is: {word}");
            }
            else
            {
                Console.WriteLine("Goodbye!");
            }
        }
    }
}