﻿using System;

namespace HW_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, m;
            int num;
            int p1 = 1;
            int p2 = 1;
            int p3 = 1;
            int p4 = 1;
            var rand = new Random();

            Console.WriteLine("Enter the first size of Matrix: ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second size of Matrix: ");
            m = Convert.ToInt32(Console.ReadLine());

            int[,] matrix = new int[n, m];
            int[,] matrixTwo = new int[n, m];
            int[,] matrixThree = new int[n, m];
            int[,] matrixFour = new int[n, m];

            Console.WriteLine("Enter the number for first Matrix: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("Matrix index: " + i + j + " ");
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                    matrix[i, j] *= num;
                }
            }

            Console.WriteLine();

            Console.WriteLine("Multiplied Matrix:");

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(matrix[i, j] + " \t");
                }

                Console.WriteLine();
            }

            Console.WriteLine();


            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    matrixThree[i, j] = 1 + rand.Next(1, 10);
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(matrixThree[i, j] + " \t");
                }

                Console.WriteLine();
            }

            Console.WriteLine();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    matrixFour[i, j] = 1 + rand.Next(1, 10);
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(matrixFour[i, j] + " \t");
                }

                Console.WriteLine();
            }

            Console.WriteLine();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    matrixTwo[i, j] = matrixThree[i, j] + matrixFour[i, j]; // Сложение третий и четвертой матрицы
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    p1 *= matrix[i, j];
                    p2 *= matrixTwo[i, j];
                    p3 *= matrixThree[i, j];
                    p4 *= matrixFour[i, j];
                }
            }

            Console.WriteLine();
            Console.WriteLine("Folded Matrix:");

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(matrixTwo[i, j] + " \t"); // Вывод сложенных матриц на консоль!
                }

                Console.WriteLine();
            }

            Console.WriteLine($"Product of first matrix: {p1}");
            Console.WriteLine($"Product of second matrix: {p2}");
            Console.WriteLine($"Product of three matrix: {p3}");
            Console.WriteLine($"Product of final matrix: {p4}");
        }
    }
}