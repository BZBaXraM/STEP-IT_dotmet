﻿using System;

namespace HW_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите арифметическое выражение в строку (например, 1 + 1 или используя оператор -): ");
            string strNum = new string(Console.ReadLine().Replace(" ", ""));
            if (strNum.IndexOf("+") != -1)
            {
                string[] numbers = strNum.Split("+");
                Console.WriteLine(Convert.ToInt32(numbers[0]) + Convert.ToInt32(numbers[1]));
            }
            else if (strNum.IndexOf("-") != -1)
            {
                string[] numbers = strNum.Split("-");
                Console.WriteLine(Convert.ToInt32(numbers[0]) - Convert.ToInt32(numbers[1]));
            }
            else
            {
                Console.WriteLine("Операция не поддерживается! ");
            }
        }
    }
}