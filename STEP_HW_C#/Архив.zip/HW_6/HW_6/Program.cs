﻿using System;

namespace HW_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the word: ");
            string word = Console.ReadLine().Replace(' ',' ');


            string str = char.ToUpper(word[0]) + word.Substring(1, word.Length - 1);
            Console.Write(str);
        }
    }
}