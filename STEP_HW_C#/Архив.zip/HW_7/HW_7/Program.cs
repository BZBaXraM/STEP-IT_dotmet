﻿using System;

namespace HW_7
{
    class MyClass
    {
        static void Main(string[] args)
        {
            string[] str = {"die", "book"};
            string text =
                "To be, or not to be, that is the question, Whether 'tis nobler in the mind to suffer The slings and arrows of" +
                " outrageous fortune, Or to take arms against a sea of troubles, And by opposing e" +
                "nd them? To die: to sleep; No more; and by a sleep to say we end The heart-ache and the thousand natural" +
                "l shocks That flesh is heir to, 'tis a consummation Devoutly to be wish'd. To die, to sleep";

            foreach (var t in str)
            {
                while (text.Contains(t))
                {
                    text = text.Replace(t, new string('*', t.Length));
                }
            }

            Console.WriteLine(text);
        }
    }
}