﻿using System;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            int num; // Если не будет работать, то добавьте default или 0 
            Console.WriteLine("Enter number: ");
            num = Convert.ToInt32(Console.ReadLine());
            if (num > 0 && num < 101)
            {
                if (num % 3 == 0 && num % 5 == 0)
                {
                    Console.WriteLine("Fizz Buzz!");
                }
                else if (num % 3 == 0)
                {
                    Console.WriteLine("Fizz!");
                }
                else if (num % 5 == 0)
                {
                    Console.WriteLine("Buzz!");
                }
                else if (!(num % 3 == 0 && num % 5 == 0))
                {
                    Console.WriteLine($"Number is: {num}");
                }
            }
            else
            {
                Console.WriteLine("Error!");
            }
        }
    }
}