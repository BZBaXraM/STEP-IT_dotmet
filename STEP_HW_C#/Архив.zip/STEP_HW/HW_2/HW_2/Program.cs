﻿using System;

namespace HW_2
{
    class Program
    {
        static void Main(String[] args)
        {
            int num, percent;

            Console.WriteLine("Enter number: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter percent of number: ");
            percent = Convert.ToInt32(Console.ReadLine());

            double result = num / 100.0 * percent;

            Console.WriteLine($"Percent of the {num} is {result}");
        }
    }
}