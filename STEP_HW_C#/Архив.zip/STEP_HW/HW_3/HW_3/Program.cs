﻿using System;

namespace HW_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, num2, num3, num4;
            int temp;

            Console.WriteLine("Enter the first number: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the fourth number: ");
            num4 = Convert.ToInt32(Console.ReadLine());

            temp = num * 1000 + num2 * 100 + num3 * 10 + num4;

            Console.WriteLine($"Number is: {temp}");
        }
    }
}