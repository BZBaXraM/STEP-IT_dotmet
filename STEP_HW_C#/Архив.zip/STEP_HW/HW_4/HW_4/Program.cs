﻿using System;

namespace HW_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, temp = 0;

            Console.WriteLine("Enter number: ");
            num = Convert.ToInt32(Console.ReadLine());

            while (num > 0)
            {
                temp = temp * 10 + num % 10;
                num /= 10;
            }

            Console.WriteLine($"Reversed number: {temp}");
        }
    }
}