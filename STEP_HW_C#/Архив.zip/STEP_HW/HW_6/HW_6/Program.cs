﻿using System;

namespace HW_6
{
    class Program
    {
        static void Main(string[] args)
        {
            float temperature;
            double fahrenheit, celsius;
            int choice;

            Console.WriteLine("Enter the temperature: ");
            temperature = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Your choice: " +
                              "1. To Celsius " +
                              "2. To Fahrenheit");
            choice = Convert.ToInt32(Console.ReadLine());

            if (choice == 1)
            {
                celsius = 5 * (temperature - 32) / 9;
                Console.WriteLine($"{temperature} in Celsius: {celsius}°C");
            }
            else if (choice == 2)
            {
                fahrenheit = 9.0 / 5.0 * temperature + 32;
                Console.WriteLine($"{temperature} in Fahrenheit: {fahrenheit}°F");
            }

            else
            {
                Console.WriteLine("Error!");
            }
        }
    }
}