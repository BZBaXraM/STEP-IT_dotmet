﻿using System;

namespace HW_7;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the first number of range: ");
        int num = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter the second number of range: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        if (num < num2)
        {
            while (num <= num2)
            {
                if (num % 2 == 0)
                {
                    Console.Write($"{num}" + " ");
                }

                num++;
            }
        }
        else if (num2 < num)
        {
            while (num2 <= num)
            {
                if (num2 % 2 == 0)
                {
                    Console.Write($"{num2}" + " ");
                }

                num2++;
            }
        }
    }
}